import React, { useEffect, useState, useMemo, useCallback } from "react";
import Chart from "react-apexcharts";
import {
  Search,
  Plus,
  X,
  GripVertical,
  ChevronDown,
  ChevronUp,
  Filter,
  BarChart3,
  TrendingDown,
  Users,
  Percent,
  ArrowRight,
  Settings2,
  RefreshCw,
  Download,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Trash2,
  Eye,
  Save,
  FolderOpen,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { getDateRangeForPreset } from "@/helpers/dateRange.helper";
import { DateRangePicker } from "@/components/DateRangePicker";
import { cn } from "@/lib/utils";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  getGA4EventNamesThunk,
  getGA4UsersFunnelThunk,
} from "@/store/dashboard/thunk";

// ============================================
// Types & Interfaces
// ============================================

interface FunnelEvent {
  eventName: string;
  eventCount: number;
  displayName?: string;
}

interface FunnelStep {
  id: string;
  eventName: string;
  displayName: string;
  users: number;
  conversionRate: number;
  dropoffRate: number;
  abandonments?: number;
  completionRate?: number;
  abandonmentRate?: number;
}

interface FunnelData {
  steps: FunnelStep[];
  totalUsers: number;
  overallConversion: number;
}

interface SavedFunnel {
  id: string;
  name: string;
  steps: string[];
  createdAt: string;
}

interface Segment {
  id: string;
  name: string;
  description: string;
  conditions: string;
  icon?: string;
}

// Available Segments Data
const AVAILABLE_SEGMENTS: Segment[] = [
  {
    id: "all_users",
    name: "All Users",
    description: "Includes all your data.",
    conditions: "",
    icon: "👥",
  },
  {
    id: "direct_traffic",
    name: "Direct traffic",
    description: "Sessions acquired directly.",
    conditions: "Session default channel group = Direct",
    icon: "👥",
  },
  {
    id: "email_sms_push",
    name: "Email, SMS & push notifications traffic",
    description: "Sessions acquired via emails, SMS or push notifications.",
    conditions:
      'Session default channel group in "Email, SMS, Mobile Push Notifications"',
    icon: "👥",
  },
  {
    id: "mobile_traffic",
    name: "Mobile traffic",
    description: "Traffic on mobile phones.",
    conditions: "Device category = mobile",
    icon: "👥",
  },
  {
    id: "organic_traffic",
    name: "Organic traffic",
    description: "Sessions acquired via organic channels.",
    conditions:
      'Session default channel group in "Organic Search, Organic Video, Organic Social, Organic Shopping"',
    icon: "👥",
  },
  {
    id: "paid_traffic",
    name: "Paid traffic",
    description: "Sessions acquired via paid channels.",
    conditions:
      'Session default channel group in "Paid Shopping, Paid Search, Paid Social, Paid Other, Paid Video, Display, Cross-network, Audio"',
    icon: "👥",
  },
  {
    id: "referral_affiliates",
    name: "Referral & affiliates traffic",
    description: "Sessions acquired via referrals or affiliates.",
    conditions: 'Session default channel group in "Referral, Affiliates"',
    icon: "👥",
  },
  {
    id: "tablet_traffic",
    name: "Tablet traffic",
    description: "Traffic on tablets.",
    conditions: "Device category = tablet",
    icon: "👥",
  },
];

// ============================================
// Demo Data - Replace with actual API calls
// ============================================

const DEMO_EVENTS: FunnelEvent[] = [
  {
    eventName: "first_open",
    eventCount: 125000,
    displayName: "First Open/Visit",
  },
  {
    eventName: "session_start",
    eventCount: 98000,
    displayName: "Session Start",
  },
  {
    eventName: "screen_view",
    eventCount: 85000,
    displayName: "Screen/Page View",
  },
  {
    eventName: "user_engagement",
    eventCount: 72000,
    displayName: "User Engagement",
  },
  { eventName: "app_open", eventCount: 68000, displayName: "App Open" },
  { eventName: "scroll", eventCount: 55000, displayName: "Scroll" },
  { eventName: "click", eventCount: 48000, displayName: "Click" },
  { eventName: "view_item", eventCount: 42000, displayName: "View Item" },
  { eventName: "add_to_cart", eventCount: 28000, displayName: "Add to Cart" },
  {
    eventName: "begin_checkout",
    eventCount: 18000,
    displayName: "Begin Checkout",
  },
  {
    eventName: "add_payment_info",
    eventCount: 15000,
    displayName: "Add Payment Info",
  },
  { eventName: "purchase", eventCount: 12000, displayName: "Purchase" },
  {
    eventName: "subscription_start",
    eventCount: 8500,
    displayName: "Subscription Start",
  },
  {
    eventName: "in_app_purchase",
    eventCount: 6200,
    displayName: "In-App Purchase",
  },
  { eventName: "share", eventCount: 4500, displayName: "Share" },
  { eventName: "login", eventCount: 45000, displayName: "Login" },
  { eventName: "sign_up", eventCount: 32000, displayName: "Sign Up" },
  {
    eventName: "tutorial_begin",
    eventCount: 28000,
    displayName: "Tutorial Begin",
  },
  {
    eventName: "tutorial_complete",
    eventCount: 22000,
    displayName: "Tutorial Complete",
  },
  { eventName: "level_start", eventCount: 18000, displayName: "Level Start" },
  { eventName: "level_end", eventCount: 15000, displayName: "Level End" },
  {
    eventName: "unlock_achievement",
    eventCount: 9500,
    displayName: "Unlock Achievement",
  },
  {
    eventName: "ad_impression",
    eventCount: 65000,
    displayName: "Ad Impression",
  },
  { eventName: "ad_click", eventCount: 4200, displayName: "Ad Click" },
  {
    eventName: "notification_receive",
    eventCount: 78000,
    displayName: "Notification Receive",
  },
  {
    eventName: "notification_open",
    eventCount: 25000,
    displayName: "Notification Open",
  },
  { eventName: "search", eventCount: 35000, displayName: "Search" },
  {
    eventName: "select_content",
    eventCount: 42000,
    displayName: "Select Content",
  },
  {
    eventName: "view_promotion",
    eventCount: 38000,
    displayName: "View Promotion",
  },
  {
    eventName: "select_promotion",
    eventCount: 12000,
    displayName: "Select Promotion",
  },
];

const generateFunnelData = (selectedEvents: string[]): FunnelData => {
  if (selectedEvents.length === 0) {
    return { steps: [], totalUsers: 0, overallConversion: 0 };
  }

  let previousUsers = 0;
  const steps: FunnelStep[] = selectedEvents.map((eventName, index) => {
    const event = DEMO_EVENTS.find((e) => e.eventName === eventName);
    const baseUsers =
      event?.eventCount || Math.floor(Math.random() * 50000) + 10000;

    // Calculate users with natural drop-off
    let users: number;
    if (index === 0) {
      users = baseUsers;
    } else {
      // Each step retains 60-90% of previous step
      const retentionRate = 0.6 + Math.random() * 0.3;
      users = Math.floor(previousUsers * retentionRate);
    }

    previousUsers = users;

    const firstStepUsers =
      selectedEvents.length > 0
        ? DEMO_EVENTS.find((e) => e.eventName === selectedEvents[0])
            ?.eventCount || users
        : users;

    const conversionRate = index === 0 ? 100 : (users / firstStepUsers) * 100;
    const dropoffRate = index === 0 ? 0 : 100 - conversionRate;

    return {
      id: `step-${index}`,
      eventName,
      displayName: event?.displayName || eventName.replace(/_/g, " "),
      users,
      conversionRate: Math.round(conversionRate * 100) / 100,
      dropoffRate: Math.round(dropoffRate * 100) / 100,
    };
  });

  const totalUsers = steps[0]?.users || 0;
  const lastStepUsers = steps[steps.length - 1]?.users || 0;
  const overallConversion =
    totalUsers > 0 ? (lastStepUsers / totalUsers) * 100 : 0;

  return {
    steps,
    totalUsers,
    overallConversion: Math.round(overallConversion * 100) / 100,
  };
};

// ============================================
// Helper Functions
// ============================================

const formatNumber = (n: number): string => {
  if (!n) return "0";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
};

// ============================================
// Sub-Components
// ============================================

interface EventSearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  events: FunnelEvent[];
  selectedSteps: string[];
  onAddEvent: (eventName: string) => void;
  onRemoveEvent?: (eventName: string) => void;
  loading?: boolean;
}

const EventSearchModal: React.FC<EventSearchModalProps> = ({
  open,
  onOpenChange,
  events,
  selectedSteps,
  onAddEvent,
  onRemoveEvent,
  loading = false,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = useMemo(() => {
    const cats = new Set<string>();
    events.forEach((e) => {
      const parts = e.eventName.split("_");
      if (parts.length > 1) {
        cats.add(parts[0]);
      }
    });
    return ["all", ...Array.from(cats)];
  }, [events]);

  const filteredEvents = useMemo(() => {
    return events.filter((event) => {
      const matchesSearch =
        event.eventName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (event.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) ??
          false);
      const matchesCategory =
        selectedCategory === "all" ||
        event.eventName.startsWith(selectedCategory);
      return matchesSearch && matchesCategory;
    });
  }, [events, searchQuery, selectedCategory]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Add Funnel Step
          </DialogTitle>
          <DialogDescription>
            Search and select events to add as funnel steps
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search & Filter */}
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search events..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat === "all"
                      ? "All Events"
                      : cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Events List */}
          <ScrollArea className="h-[400px] rounded-md border">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredEvents.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <AlertCircle className="h-8 w-8 mb-2" />
                <p>No events found</p>
              </div>
            ) : (
              <div className="p-2 space-y-1">
                {filteredEvents.map((event) => {
                  const isSelected = selectedSteps.includes(event.eventName);
                  return (
                    <div
                      key={event.eventName}
                      className={cn(
                        "flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors",
                        isSelected
                          ? "bg-primary/10 border border-primary/20"
                          : "hover:bg-muted/50 border border-transparent"
                      )}
                      onClick={() => {
                        if (isSelected) {
                          // If already selected, remove it
                          if (onRemoveEvent) {
                            onRemoveEvent(event.eventName);
                          }
                        } else {
                          // If not selected, add it
                          onAddEvent(event.eventName);
                        }
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            isSelected
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          )}
                        >
                          {isSelected ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <BarChart3 className="h-4 w-4" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-sm">
                            {event.displayName ||
                              event.eventName.replace(/_/g, " ")}
                          </p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {event.eventName}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Dimension Search Modal Component
interface DimensionSearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  availableDimensions: Array<{ id: string; name: string; icon: string }>;
  selectedDimensions: string[];
  onAddDimension: (dimensionId: string) => void;
  onRemoveDimension?: (dimensionId: string) => void;
}

const DimensionSearchModal: React.FC<DimensionSearchModalProps> = ({
  open,
  onOpenChange,
  availableDimensions,
  selectedDimensions,
  onAddDimension,
  onRemoveDimension,
}) => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredDimensions = useMemo(() => {
    return availableDimensions.filter((dim) => {
      return (
        dim.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dim.id.toLowerCase().includes(searchQuery.toLowerCase())
      );
    });
  }, [availableDimensions, searchQuery]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Add Dimension
          </DialogTitle>
          <DialogDescription>
            Select dimensions to break down your funnel data
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search dimensions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Dimensions List */}
          <ScrollArea className="h-[350px] rounded-md border">
            {filteredDimensions.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <AlertCircle className="h-8 w-8 mb-2" />
                <p>No dimensions found</p>
              </div>
            ) : (
              <div className="p-2 space-y-1">
                {filteredDimensions.map((dimension) => {
                  const isSelected = selectedDimensions.includes(dimension.id);
                  return (
                    <div
                      key={dimension.id}
                      className={cn(
                        "flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors",
                        isSelected
                          ? "bg-primary/10 border border-primary/20"
                          : "hover:bg-muted/50 border border-transparent"
                      )}
                      onClick={() => {
                        if (isSelected) {
                          // If already selected, remove it
                          if (onRemoveDimension) {
                            onRemoveDimension(dimension.id);
                          }
                        } else {
                          // If not selected, add it
                          onAddDimension(dimension.id);
                        }
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            isSelected
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          )}
                        >
                          {isSelected ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <span className="text-sm">{dimension.icon}</span>
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-sm">
                            {dimension.name}
                          </p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {dimension.id}
                          </p>
                        </div>
                      </div>
                      {isSelected && (
                        <Badge variant="secondary" className="text-xs">
                          Added
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};

interface FunnelStepCardProps {
  step: FunnelStep;
  index: number;
  totalSteps: number;
  onRemove: () => void;
  previousUsers?: number;
}

const FunnelStepCard: React.FC<FunnelStepCardProps> = ({
  step,
  index,
  totalSteps,
  onRemove,
  previousUsers,
}) => {
  const stepDropoff = previousUsers
    ? ((previousUsers - step.users) / previousUsers) * 100
    : 0;
  const stepConversion = previousUsers
    ? (step.users / previousUsers) * 100
    : 100;

  return (
    <div className="relative">
      {/* Step Card */}
      <Card className="relative overflow-hidden group">
        <div
          className="absolute left-0 top-0 bottom-0 bg-primary/10"
          style={{ width: `${step.conversionRate}%` }}
        />
        <CardContent className="relative p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold text-sm">
                  {index + 1}
                </div>
              </div>
              <div>
                <p className="font-semibold">{step.displayName}</p>
                <p className="text-xs text-muted-foreground font-mono">
                  {step.eventName}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              {/* Users Count */}
              <div className="text-right">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="font-bold text-lg">
                    {formatNumber(step.users)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">users</p>
              </div>

              {/* Conversion Rate */}
              <div className="text-right">
                <div className="flex items-center gap-1">
                  <Percent className="h-4 w-4 text-green-500" />
                  <span className="font-bold text-lg text-green-600">
                    {step.conversionRate.toFixed(1)}%
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">from start</p>
              </div>

              {/* Step Conversion (from previous) */}
              {index > 0 && (
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <TrendingDown className="h-4 w-4 text-orange-500" />
                    <span className="font-bold text-lg text-orange-600">
                      {stepConversion.toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">from prev</p>
                </div>
              )}

              {/* Remove Button */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={onRemove}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Remove step</TooltipContent>
              </Tooltip>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Connector Arrow */}
      {index < totalSteps - 1 && (
        <div className="flex items-center justify-center py-2">
          <div className="flex flex-col items-center">
            <div className="w-0.5 h-4 bg-border" />
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-muted text-xs">
              <ArrowRight className="h-3 w-3" />
              <span className="font-medium text-red-500">
                -{stepDropoff.toFixed(1)}% dropoff
              </span>
            </div>
            <div className="w-0.5 h-4 bg-border" />
          </div>
        </div>
      )}
    </div>
  );
};

interface FunnelVisualizationProps {
  data: FunnelData;
}

const FunnelVisualization: React.FC<FunnelVisualizationProps> = ({ data }) => {
  if (data.steps.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
        <BarChart3 className="h-12 w-12 mb-3 opacity-50" />
        <p className="text-base font-medium">No funnel steps selected</p>
        <p className="text-sm">Add events to build your funnel</p>
      </div>
    );
  }

  // Calculate dynamic height based on number of steps - 45px per bar for good readability
  const barHeight = 45;
  const chartHeight = Math.max(250, data.steps.length * barHeight + 60);

  // Keep steps in the order they were added (funnel order)
  const series = [
    {
      name: "Users",
      data: data.steps.map((step) => step.users || 0),
    },
  ];

  const options: ApexCharts.ApexOptions = {
    chart: {
      type: "bar",
      height: chartHeight,
      toolbar: {
        show: false,
      },
      background: "transparent",
      animations: {
        enabled: true,
        speed: 500,
      },
    },
    plotOptions: {
      bar: {
        borderRadius: 6,
        horizontal: true,
        barHeight: "70%",
        distributed: false,
        dataLabels: {
          position: "center",
        },
      },
    },
    colors: ["#3b82f6"], // Single blue color for all bars
    fill: {
      type: "gradient",
      gradient: {
        shade: "light",
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: ["#60a5fa"],
        inverseColors: false,
        opacityFrom: 1,
        opacityTo: 0.85,
        stops: [0, 100],
      },
    },
    dataLabels: {
      enabled: true,
      textAnchor: "start",
      formatter: function (val: number, opt: any) {
        const step = data.steps[opt.dataPointIndex];
        return `${step?.displayName}: ${formatNumber(val)}`;
      },
      offsetX: 10,
      style: {
        fontSize: "13px",
        fontWeight: 600,
        colors: ["#fff"],
      },
      background: {
        enabled: false,
      },
    },
    xaxis: {
      categories: data.steps.map((step) => step.displayName),
      labels: {
        show: true,
        style: {
          fontSize: "11px",
          colors: "#94a3b8",
        },
        formatter: function (val: string) {
          return formatNumber(Number(val));
        },
      },
      axisBorder: {
        show: false,
      },
      axisTicks: {
        show: false,
      },
    },
    yaxis: {
      labels: {
        show: false,
      },
    },
    grid: {
      show: true,
      borderColor: "#334155",
      strokeDashArray: 4,
      xaxis: {
        lines: {
          show: true,
        },
      },
      yaxis: {
        lines: {
          show: false,
        },
      },
      padding: {
        left: 5,
        right: 20,
        top: 10,
        bottom: 10,
      },
    },
    legend: {
      show: false,
    },
    tooltip: {
      enabled: true,
      theme: "dark",
      y: {
        formatter: function (val: number) {
          return formatNumber(val) + " users";
        },
      },
    },
  };

  return (
    <div className="w-full">
      <Chart
        options={options}
        series={series}
        type="bar"
        height={chartHeight}
        width="100%"
      />
    </div>
  );
};

// ============================================
// Funnel Table Types & Component
// ============================================

interface FunnelTableRow {
  stepName: string;
  stepNumber: number;
  country: string;
  isTotal: boolean;
  activeUsers: number;
  percentOfStep1: number;
  completionRate: number;
  abandonments: number;
  abandonmentRate: number;
}

interface FunnelTableProps {
  data: FunnelData;
  breakdownDimension: string;
  rowsPerDimension: number;
}

// Demo country breakdown data
const COUNTRY_BREAKDOWN = [
  { country: "India", percentage: 0.39 },
  { country: "Peru", percentage: 0.128 },
  { country: "Brazil", percentage: 0.095 },
  { country: "Saudi Arabia", percentage: 0.068 },
  { country: "Mexico", percentage: 0.06 },
  { country: "United States", percentage: 0.055 },
  { country: "Indonesia", percentage: 0.048 },
  { country: "Pakistan", percentage: 0.035 },
  { country: "Philippines", percentage: 0.032 },
  { country: "Egypt", percentage: 0.028 },
];

const generateTableData = (
  funnelData: FunnelData,
  breakdownDimension: string,
  rowsPerDimension: number
): FunnelTableRow[] => {
  if (funnelData.steps.length === 0) return [];

  const rows: FunnelTableRow[] = [];
  const firstStepUsers = funnelData.steps[0]?.users || 1;

  funnelData.steps.forEach((step, stepIndex) => {
    const previousStep = stepIndex > 0 ? funnelData.steps[stepIndex - 1] : null;
    const previousUsers = previousStep?.users || step.users;
    // Use API data if available, otherwise calculate
    const abandonments =
      step.abandonments !== undefined
        ? step.abandonments
        : previousUsers - step.users;
    const completionRate =
      step.completionRate !== undefined
        ? step.completionRate
        : previousUsers > 0
        ? (step.users / previousUsers) * 100
        : 100;
    const abandonmentRate =
      step.abandonmentRate !== undefined
        ? step.abandonmentRate
        : 100 - completionRate;

    // Add total row for each step
    rows.push({
      stepName: step.displayName,
      stepNumber: stepIndex + 1,
      country: "Total",
      isTotal: true,
      activeUsers: step.users,
      percentOfStep1: (step.users / firstStepUsers) * 100,
      completionRate: stepIndex === 0 ? 100 : completionRate,
      abandonments:
        stepIndex === 0
          ? step.abandonments !== undefined
            ? step.abandonments
            : Math.floor(step.users * 0.006)
          : abandonments,
      abandonmentRate:
        stepIndex === 0
          ? step.abandonmentRate !== undefined
            ? step.abandonmentRate
            : 0.63
          : abandonmentRate,
    });

    // Add country breakdown rows if breakdown is enabled
    if (breakdownDimension === "country") {
      const countriesToShow = COUNTRY_BREAKDOWN.slice(0, rowsPerDimension);
      countriesToShow.forEach((countryData) => {
        const countryUsers = Math.floor(step.users * countryData.percentage);
        const countryPrevUsers = previousStep
          ? Math.floor(previousStep.users * countryData.percentage)
          : countryUsers;
        const countryAbandonments = countryPrevUsers - countryUsers;
        const countryCompletionRate =
          countryPrevUsers > 0 ? (countryUsers / countryPrevUsers) * 100 : 100;
        const countryAbandonmentRate = 100 - countryCompletionRate;

        rows.push({
          stepName: step.displayName,
          stepNumber: stepIndex + 1,
          country: countryData.country,
          isTotal: false,
          activeUsers: countryUsers,
          percentOfStep1: (countryUsers / firstStepUsers) * 100,
          completionRate: stepIndex === 0 ? 100 : countryCompletionRate,
          abandonments:
            stepIndex === 0
              ? Math.floor(countryUsers * 0.005)
              : countryAbandonments,
          abandonmentRate:
            stepIndex === 0
              ? Math.random() * 0.5 + 0.3
              : countryAbandonmentRate,
        });
      });
    }
  });

  return rows;
};

const FunnelTable: React.FC<FunnelTableProps> = ({
  data,
  breakdownDimension,
  rowsPerDimension,
}) => {
  const tableData = useMemo(
    () => generateTableData(data, breakdownDimension, rowsPerDimension),
    [data, breakdownDimension, rowsPerDimension]
  );

  if (data.steps.length === 0) {
    return null;
  }

  // Group rows by step for rendering
  const groupedByStep: { [key: number]: FunnelTableRow[] } = {};
  tableData.forEach((row) => {
    if (!groupedByStep[row.stepNumber]) {
      groupedByStep[row.stepNumber] = [];
    }
    groupedByStep[row.stepNumber].push(row);
  });

  return (
    <div className="overflow-x-auto">
      <div className="h-[500px] overflow-y-auto border rounded-md">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 sticky top-0 z-10">
            <tr className="border-b">
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                Step
              </th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                {breakdownDimension === "country" ? "Country" : "Breakdown"}
              </th>
              <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                Active users (% of Step 1)
              </th>
              <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                Completion rate
              </th>
              <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                Abandonments
              </th>
              <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                Abandonment rate
              </th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(groupedByStep).map(([stepNum, stepRows]) => (
              <React.Fragment key={stepNum}>
                {stepRows.map((row, rowIndex) => (
                  <tr
                    key={`${stepNum}-${row.country}-${rowIndex}`}
                    className={cn(
                      "border-b hover:bg-muted/30 transition-colors",
                      row.isTotal && "bg-muted/20 font-medium"
                    )}
                  >
                    <td className="py-3 px-4">
                      {row.isTotal ? (
                        <span className="text-muted-foreground">
                          {row.stepNumber}. {row.stepName}
                        </span>
                      ) : null}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={cn(
                          row.isTotal ? "font-semibold" : "text-blue-600"
                        )}
                      >
                        {row.country}
                      </span>
                    </td>
                    <td className="text-right py-3 px-4">
                      <span className="text-blue-600">
                        {formatNumber(row.activeUsers)}
                      </span>
                      <span className="text-muted-foreground ml-1">
                        ({row.percentOfStep1.toFixed(2)}%)
                      </span>
                    </td>
                    <td className="text-right py-3 px-4">
                      {row.completionRate.toFixed(2)}%
                    </td>
                    <td className="text-right py-3 px-4">
                      <span
                        className={cn(
                          row.abandonments > 0 ? "text-blue-600" : ""
                        )}
                      >
                        {formatNumber(row.abandonments)}
                      </span>
                    </td>
                    <td className="text-right py-3 px-4">
                      <span
                        className={cn(
                          row.abandonmentRate > 50
                            ? "text-red-500"
                            : row.abandonmentRate > 10
                            ? "text-orange-500"
                            : "text-green-600"
                        )}
                      >
                        {row.abandonmentRate.toFixed(2)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================
// Main Component
// ============================================

const FunnelAnalytics: React.FC = () => {
  const dispatch = useAppDispatch();
  const { eventNames, eventNamesLoading, usersFunnel, usersFunnelLoading } =
    useAppSelector((state) => state.Dashboard);

  // State
  const [selectedSteps, setSelectedSteps] = useState<string[]>([]);
  const [isAddEventOpen, setIsAddEventOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Date Range State
  const [preset, setPreset] = useState("last28");
  const [startDate, setStartDate] = useState(
    getDateRangeForPreset("last28").startDate
  );
  const [endDate, setEndDate] = useState(
    getDateRangeForPreset("last28").endDate
  );

  // Filters
  const [deviceCategory, setDeviceCategory] = useState("all");
  const [country, setCountry] = useState("all");

  // Dimensions State
  const [selectedDimensions, setSelectedDimensions] = useState<string[]>([
    "country",
    "deviceCategory",
    "appVersion",
    "osVersion",
    "device",
  ]);
  const [isAddDimensionOpen, setIsAddDimensionOpen] = useState(false);

  // Segments State
  const [selectedSegments, setSelectedSegments] = useState<string[]>([
    "all_users",
  ]);
  const [isAddSegmentOpen, setIsAddSegmentOpen] = useState(false);
  const [segmentSearchQuery, setSegmentSearchQuery] = useState("");

  // Breakdown State
  const [breakdownDimension, setBreakdownDimension] = useState<string>("");
  const [rowsPerDimension, setRowsPerDimension] = useState<string>("10");
  const [showElapsedTime, setShowElapsedTime] = useState(false);

  // Available Dimensions
  const availableDimensions = [
    { id: "country", name: "Country", icon: "🌍" },
    { id: "deviceCategory", name: "Device category", icon: "📱" },
    { id: "appVersion", name: "App version", icon: "📦" },
    { id: "osVersion", name: "OS version", icon: "💻" },
    { id: "device", name: "Device", icon: "🖥️" },
  ];

  // Saved Funnels
  const [savedFunnels, setSavedFunnels] = useState<SavedFunnel[]>([
    {
      id: "1",
      name: "Purchase Funnel",
      steps: [
        "first_open",
        "session_start",
        "view_item",
        "add_to_cart",
        "purchase",
      ],
      createdAt: "2025-12-28",
    },
    {
      id: "2",
      name: "Onboarding Funnel",
      steps: ["first_open", "tutorial_begin", "tutorial_complete", "sign_up"],
      createdAt: "2025-12-25",
    },
  ]);
  const [saveFunnelName, setSaveFunnelName] = useState("");
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);

  // Fetch event names from API
  useEffect(() => {
    const params = new URLSearchParams({
      startDate,
      endDate,
    });
    dispatch(getGA4EventNamesThunk(params.toString()));
  }, [dispatch, startDate, endDate]);

  // Fetch users funnel data from API (POST request without body)
  useEffect(() => {
    dispatch(getGA4UsersFunnelThunk({}));
  }, [dispatch]);

  // Automatically add events from API to Funnel Steps
  useEffect(() => {
    if (usersFunnel && usersFunnel.stages && usersFunnel.stages.length > 0) {
      const eventNames = usersFunnel.stages.map((stage) => stage.eventName);
      setSelectedSteps(eventNames);
    }
  }, [usersFunnel]);

  // Transform API data to FunnelEvent format
  const events: FunnelEvent[] = useMemo(() => {
    if (eventNames?.data && Array.isArray(eventNames.data)) {
      return eventNames.data
        .filter(
          (eventName: string | null | undefined) =>
            eventName && typeof eventName === "string"
        )
        .map((eventName: string) => ({
          eventName: eventName,
          eventCount: 0, // API doesn't provide count, will be fetched separately if needed
          displayName: eventName
            .split("_")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" "),
        }));
    }
    return [];
  }, [eventNames]);

  // Set first 5 events as default selected steps when events load
  // useEffect(() => {
  //   if (events.length > 0 && selectedSteps.length === 0) {
  //     const first5Events = events.slice(0, 5).map((e) => e.eventName);
  //     setSelectedSteps(first5Events);
  //   }
  // }, [events]);

  // Computed Data - Use API data for funnel based on selectedSteps
  const funnelData = useMemo(() => {
    // If API data is available and steps are selected
    if (
      usersFunnel &&
      usersFunnel.stages &&
      usersFunnel.stages.length > 0 &&
      selectedSteps.length > 0
    ) {
      // Create a map of eventName to stage data for quick lookup
      const stageMap = new Map(
        usersFunnel.stages.map((stage) => [stage.eventName, stage])
      );

      // Build steps based on selectedSteps order, using API data
      const steps: FunnelStep[] = selectedSteps
        .map((eventName, index) => {
          const stage = stageMap.get(eventName);
          if (!stage) return null; // Skip if stage not found in API data

          const event = events.find((e) => e.eventName === eventName);
          return {
            id: `step-${index}`,
            eventName: stage.eventName,
            displayName:
              event?.displayName || stage.eventName.replace(/_/g, " "),
            users: stage.users,
            conversionRate: stage.conversionRate,
            dropoffRate: stage.dropOffRate,
            abandonments: stage.abandonments,
            completionRate: stage.completionRate,
            abandonmentRate: stage.abandonmentRate,
          } as FunnelStep;
        })
        .filter((step) => step !== null) as FunnelStep[];

      // Calculate total users from first step (if available)
      const firstStep = steps[0];
      const totalUsers =
        firstStep?.users || usersFunnel.summary.totalUsersAtStart;

      // Calculate overall conversion from first to last step
      const lastStep = steps[steps.length - 1];
      const overallConversion =
        totalUsers > 0 && lastStep
          ? (lastStep.users / totalUsers) * 100
          : usersFunnel.summary.overallConversionRate;

      return {
        steps,
        totalUsers,
        overallConversion: Math.round(overallConversion * 100) / 100,
      };
    }

    // Fallback to empty if no API data or no selected steps
    return { steps: [], totalUsers: 0, overallConversion: 0 };
  }, [usersFunnel, events, selectedSteps]);

  // Handlers
  const handleAddEvent = useCallback((eventName: string) => {
    setSelectedSteps((prev) => [...prev, eventName]);
  }, []);

  const handleRemoveEvent = useCallback((eventName: string) => {
    setSelectedSteps((prev) => prev.filter((e) => e !== eventName));
  }, []);

  const handleRemoveStep = useCallback((index: number) => {
    setSelectedSteps((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleClearAll = useCallback(() => {
    setSelectedSteps([]);
  }, []);

  // Dimension Handlers
  const handleAddDimension = useCallback((dimensionId: string) => {
    setSelectedDimensions((prev) => {
      if (prev.includes(dimensionId)) return prev;
      return [...prev, dimensionId];
    });
  }, []);

  const handleRemoveDimension = useCallback((dimensionId: string) => {
    setSelectedDimensions((prev) => prev.filter((d) => d !== dimensionId));
  }, []);

  const handleClearDimensions = useCallback(() => {
    setSelectedDimensions([]);
  }, []);

  // Segment Handlers
  const handleToggleSegment = useCallback((segmentId: string) => {
    setSelectedSegments((prev) => {
      if (prev.includes(segmentId)) {
        return prev.filter((s) => s !== segmentId);
      }
      return [...prev, segmentId];
    });
  }, []);

  const handleRemoveSegment = useCallback((segmentId: string) => {
    setSelectedSegments((prev) => prev.filter((s) => s !== segmentId));
  }, []);

  const handleClearSegments = useCallback(() => {
    setSelectedSegments([]);
  }, []);

  const filteredSegments = useMemo(() => {
    return AVAILABLE_SEGMENTS.filter(
      (segment) =>
        segment.name.toLowerCase().includes(segmentSearchQuery.toLowerCase()) ||
        segment.description
          .toLowerCase()
          .includes(segmentSearchQuery.toLowerCase())
    );
  }, [segmentSearchQuery]);

  // Drag and Drop State
  const [draggedStepIndex, setDraggedStepIndex] = useState<number | null>(null);
  const [dropTargetStepIndex, setDropTargetStepIndex] = useState<number | null>(
    null
  );
  const [draggedDimensionIndex, setDraggedDimensionIndex] = useState<
    number | null
  >(null);
  const [dropTargetDimensionIndex, setDropTargetDimensionIndex] = useState<
    number | null
  >(null);
  const [draggedSegmentIndex, setDraggedSegmentIndex] = useState<number | null>(
    null
  );
  const [dropTargetSegmentIndex, setDropTargetSegmentIndex] = useState<
    number | null
  >(null);

  // Drag Handlers for Steps
  const handleStepDragStart = useCallback(
    (e: React.DragEvent, index: number) => {
      setDraggedStepIndex(index);
      e.dataTransfer.effectAllowed = "move";
    },
    []
  );

  const handleStepDragOver = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      if (draggedStepIndex !== null && draggedStepIndex !== index) {
        setDropTargetStepIndex(index);
      }
    },
    [draggedStepIndex]
  );

  const handleStepDragLeave = useCallback(() => {
    setDropTargetStepIndex(null);
  }, []);

  const handleStepDrop = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      if (draggedStepIndex === null || draggedStepIndex === index) return;

      setSelectedSteps((prev) => {
        const newSteps = [...prev];
        const draggedItem = newSteps[draggedStepIndex];
        newSteps.splice(draggedStepIndex, 1);
        newSteps.splice(index, 0, draggedItem);
        return newSteps;
      });
      setDraggedStepIndex(null);
      setDropTargetStepIndex(null);
    },
    [draggedStepIndex]
  );

  const handleStepDragEnd = useCallback(() => {
    setDraggedStepIndex(null);
    setDropTargetStepIndex(null);
  }, []);

  // Drag Handlers for Dimensions
  const handleDimensionDragStart = useCallback(
    (e: React.DragEvent, index: number) => {
      setDraggedDimensionIndex(index);
      e.dataTransfer.effectAllowed = "move";
    },
    []
  );

  const handleDimensionDragOver = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      if (draggedDimensionIndex !== null && draggedDimensionIndex !== index) {
        setDropTargetDimensionIndex(index);
      }
    },
    [draggedDimensionIndex]
  );

  const handleDimensionDragLeave = useCallback(() => {
    setDropTargetDimensionIndex(null);
  }, []);

  const handleDimensionDrop = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      if (draggedDimensionIndex === null || draggedDimensionIndex === index)
        return;

      setSelectedDimensions((prev) => {
        const newDimensions = [...prev];
        const draggedItem = newDimensions[draggedDimensionIndex];
        newDimensions.splice(draggedDimensionIndex, 1);
        newDimensions.splice(index, 0, draggedItem);
        return newDimensions;
      });
      setDraggedDimensionIndex(null);
      setDropTargetDimensionIndex(null);
    },
    [draggedDimensionIndex]
  );

  const handleDimensionDragEnd = useCallback(() => {
    setDraggedDimensionIndex(null);
    setDropTargetDimensionIndex(null);
  }, []);

  // Drag Handlers for Segments
  const handleSegmentDragStart = useCallback(
    (e: React.DragEvent, index: number) => {
      setDraggedSegmentIndex(index);
      e.dataTransfer.effectAllowed = "move";
    },
    []
  );

  const handleSegmentDragOver = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      if (draggedSegmentIndex !== null && draggedSegmentIndex !== index) {
        setDropTargetSegmentIndex(index);
      }
    },
    [draggedSegmentIndex]
  );

  const handleSegmentDragLeave = useCallback(() => {
    setDropTargetSegmentIndex(null);
  }, []);

  const handleSegmentDrop = useCallback(
    (e: React.DragEvent, index: number) => {
      e.preventDefault();
      if (draggedSegmentIndex === null || draggedSegmentIndex === index) return;

      setSelectedSegments((prev) => {
        const newSegments = [...prev];
        const draggedItem = newSegments[draggedSegmentIndex];
        newSegments.splice(draggedSegmentIndex, 1);
        newSegments.splice(index, 0, draggedItem);
        return newSegments;
      });
      setDraggedSegmentIndex(null);
      setDropTargetSegmentIndex(null);
    },
    [draggedSegmentIndex]
  );

  const handleSegmentDragEnd = useCallback(() => {
    setDraggedSegmentIndex(null);
    setDropTargetSegmentIndex(null);
  }, []);

  const handleRefresh = useCallback(() => {
    const params = new URLSearchParams({
      startDate,
      endDate,
    });
    dispatch(getGA4EventNamesThunk(params.toString()));
    // Users funnel API is a POST request with empty body
    dispatch(getGA4UsersFunnelThunk({}));
  }, [dispatch, startDate, endDate]);

  const handleSaveFunnel = useCallback(() => {
    if (!saveFunnelName.trim() || selectedSteps.length === 0) return;

    const newFunnel: SavedFunnel = {
      id: Date.now().toString(),
      name: saveFunnelName,
      steps: selectedSteps,
      createdAt: new Date().toISOString().split("T")[0],
    };

    setSavedFunnels((prev) => [...prev, newFunnel]);
    setSaveFunnelName("");
    setIsSaveDialogOpen(false);
  }, [saveFunnelName, selectedSteps]);

  const handleLoadFunnel = useCallback((funnel: SavedFunnel) => {
    setSelectedSteps(funnel.steps);
  }, []);

  const handleDeleteSavedFunnel = useCallback((funnelId: string) => {
    setSavedFunnels((prev) => prev.filter((f) => f.id !== funnelId));
  }, []);

  const handleExport = useCallback(() => {
    const exportData = {
      funnel: selectedSteps,
      data: funnelData,
      dateRange: { startDate, endDate },
      filters: { deviceCategory, country },
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `funnel-export-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [selectedSteps, funnelData, startDate, endDate, deviceCategory, country]);

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col overflow-hidden p-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-shrink-0 mb-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="h-7 w-7" />
            Funnel Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Build and analyze custom conversion funnels from your events
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={usersFunnelLoading || eventNamesLoading}
          >
            <RefreshCw
              className={cn(
                "h-4 w-4 mr-2",
                (usersFunnelLoading || eventNamesLoading) && "animate-spin"
              )}
            />
            Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Filters Bar */}
      <Card className="flex-shrink-0 mb-3">
        <CardContent className="p-3">
          <div className="flex flex-wrap items-center gap-4">
            {/* Date Range */}
            <div className="flex items-center gap-2">
              <Label className="text-sm font-medium">Date Range:</Label>
              <Select
                value={preset}
                onValueChange={(v) => {
                  setPreset(v);
                  if (v !== "custom") {
                    const r = getDateRangeForPreset(v);
                    setStartDate(r.startDate);
                    setEndDate(r.endDate);
                  }
                }}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last7">Last 7 days</SelectItem>
                  <SelectItem value="last28">Last 28 days</SelectItem>
                  <SelectItem value="last30">Last 30 days</SelectItem>
                  <SelectItem value="last90">Last 90 days</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
              {preset === "custom" && (
                <DateRangePicker
                  startDate={startDate}
                  endDate={endDate}
                  onStartDateChange={setStartDate}
                  onEndDateChange={setEndDate}
                />
              )}
            </div>

            <Separator orientation="vertical" className="h-8" />

            {/* Device Category */}
            <div className="flex items-center gap-2">
              <Label className="text-sm font-medium">Device:</Label>
              <Select value={deviceCategory} onValueChange={setDeviceCategory}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Devices</SelectItem>
                  <SelectItem value="mobile">Mobile</SelectItem>
                  <SelectItem value="tablet">Tablet</SelectItem>
                  <SelectItem value="desktop">Desktop</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Country */}
            <div className="flex items-center gap-2">
              <Label className="text-sm font-medium">Country:</Label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Countries</SelectItem>
                  <SelectItem value="US">United States</SelectItem>
                  <SelectItem value="IN">India</SelectItem>
                  <SelectItem value="GB">United Kingdom</SelectItem>
                  <SelectItem value="DE">Germany</SelectItem>
                  <SelectItem value="BR">Brazil</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1" />

            {/* Saved Funnels */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <FolderOpen className="h-4 w-4 mr-2" />
                  Saved Funnels
                  <ChevronDown className="h-4 w-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                {savedFunnels.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground text-sm">
                    No saved funnels
                  </div>
                ) : (
                  savedFunnels.map((funnel) => (
                    <DropdownMenuItem
                      key={funnel.id}
                      className="flex items-center justify-between"
                      onClick={() => handleLoadFunnel(funnel)}
                    >
                      <div>
                        <p className="font-medium">{funnel.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {funnel.steps.length} steps • {funnel.createdAt}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteSavedFunnel(funnel.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </DropdownMenuItem>
                  ))
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setIsSaveDialogOpen(true)}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Current Funnel
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Main Content - Side by Side Layout */}
      <div className="flex gap-4 flex-1 min-h-0 overflow-hidden">
        {/* Left Sidebar - Variables Panel (like Google Analytics) */}
        <div className="w-80 flex-shrink-0 flex flex-col gap-3 overflow-y-auto pr-2">
          {/* Segments Section */}
          <Card className="flex flex-col">
            <CardHeader className="pb-2 flex-shrink-0 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Segments
                </CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => setIsAddSegmentOpen(true)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-3 space-y-1 max-h-[180px] overflow-y-auto">
                {selectedSegments.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <Users className="h-5 w-5 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">No segments added</p>
                    <p className="text-xs opacity-70">
                      Click + to add segments
                    </p>
                  </div>
                ) : (
                  selectedSegments.map((segmentId, index) => {
                    const segment = AVAILABLE_SEGMENTS.find(
                      (s) => s.id === segmentId
                    );
                    const isDragging = draggedSegmentIndex === index;
                    const isDropTarget = dropTargetSegmentIndex === index;
                    return (
                      <div
                        key={segmentId}
                        draggable
                        onDragStart={(e) => handleSegmentDragStart(e, index)}
                        onDragOver={(e) => handleSegmentDragOver(e, index)}
                        onDragLeave={handleSegmentDragLeave}
                        onDrop={(e) => handleSegmentDrop(e, index)}
                        onDragEnd={handleSegmentDragEnd}
                        className={cn(
                          "flex items-center gap-2 p-2 rounded border bg-background hover:bg-muted/50 group transition-all duration-150 select-none",
                          isDragging &&
                            "opacity-50 border-dashed border-primary/50",
                          isDropTarget &&
                            !isDragging &&
                            "bg-primary/5 border-primary"
                        )}
                      >
                        <GripVertical className="h-3.5 w-3.5 text-muted-foreground/50 cursor-grab active:cursor-grabbing flex-shrink-0" />
                        <span className="text-sm truncate flex-1">
                          {segment?.name || segmentId}
                        </span>
                        <Users className="h-3.5 w-3.5 text-muted-foreground/50 flex-shrink-0" />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 opacity-0 group-hover:opacity-100 flex-shrink-0"
                          onClick={() => handleRemoveSegment(segmentId)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>

          {/* Funnel Steps Section */}
          <Card className="flex flex-col">
            <CardHeader className="pb-2 flex-shrink-0 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Settings2 className="h-4 w-4" />
                  Funnel Steps
                </CardTitle>
                <div className="flex items-center gap-1">
                  {selectedSteps.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={handleClearAll}
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-3 space-y-1 max-h-[200px] overflow-y-auto">
                {selectedSteps.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <Plus className="h-6 w-6 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">No steps added yet</p>
                    <p className="text-xs opacity-70">
                      Click below to add events
                    </p>
                  </div>
                ) : (
                  selectedSteps.map((eventName, index) => {
                    const event = events.find((e) => e.eventName === eventName);
                    const isDragging = draggedStepIndex === index;
                    const isDropTarget = dropTargetStepIndex === index;
                    return (
                      <div
                        key={`${eventName}-${index}`}
                        draggable
                        onDragStart={(e) => handleStepDragStart(e, index)}
                        onDragOver={(e) => handleStepDragOver(e, index)}
                        onDragLeave={handleStepDragLeave}
                        onDrop={(e) => handleStepDrop(e, index)}
                        onDragEnd={handleStepDragEnd}
                        className={cn(
                          "flex items-center gap-2 p-2 rounded border bg-background hover:bg-muted/50 group transition-all duration-150 select-none",
                          isDragging &&
                            "opacity-50 border-dashed border-primary/50",
                          isDropTarget &&
                            !isDragging &&
                            "bg-primary/5 border-primary"
                        )}
                      >
                        <GripVertical className="h-3.5 w-3.5 text-muted-foreground/50 cursor-grab active:cursor-grabbing flex-shrink-0" />
                        <div className="w-5 h-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[10px] font-semibold flex-shrink-0">
                          {index + 1}
                        </div>
                        <span className="text-sm truncate flex-1">
                          {event?.displayName || eventName.replace(/_/g, " ")}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 opacity-0 group-hover:opacity-100 flex-shrink-0"
                          onClick={() => handleRemoveStep(index)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
            <div className="p-3 border-t flex-shrink-0">
              <Button
                variant="outline"
                className="w-full h-8 text-xs"
                onClick={() => setIsAddEventOpen(true)}
              >
                <Plus className="h-3.5 w-3.5 mr-1.5" />
                Add Step
              </Button>
            </div>
          </Card>

          {/* Dimensions Section */}
          <Card className="flex flex-col">
            <CardHeader className="pb-2 flex-shrink-0 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  Dimensions
                </CardTitle>
                {/* <div className="flex items-center gap-1">
                  {selectedDimensions.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={handleClearDimensions}
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Clear
                    </Button>
                  )}
                </div> */}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-3 space-y-1 max-h-[180px] overflow-y-auto">
                {selectedDimensions.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <Filter className="h-5 w-5 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">No dimensions added yet</p>
                    <p className="text-xs opacity-70">
                      Click below to add dimensions
                    </p>
                  </div>
                ) : (
                  selectedDimensions.map((dimensionId, index) => {
                    const dimension = availableDimensions.find(
                      (d) => d.id === dimensionId
                    );
                    const isDragging = draggedDimensionIndex === index;
                    const isDropTarget = dropTargetDimensionIndex === index;
                    return (
                      <div
                        key={`${dimensionId}-${index}`}
                        draggable
                        onDragStart={(e) => handleDimensionDragStart(e, index)}
                        onDragOver={(e) => handleDimensionDragOver(e, index)}
                        onDragLeave={handleDimensionDragLeave}
                        onDrop={(e) => handleDimensionDrop(e, index)}
                        onDragEnd={handleDimensionDragEnd}
                        className={cn(
                          "flex items-center gap-2 p-2 rounded border bg-background hover:bg-muted/50 group transition-all duration-150 select-none",
                          isDragging &&
                            "opacity-50 border-dashed border-primary/50",
                          isDropTarget &&
                            !isDragging &&
                            "bg-primary/5 border-primary"
                        )}
                      >
                        <GripVertical className="h-3.5 w-3.5 text-muted-foreground/50 cursor-grab active:cursor-grabbing flex-shrink-0" />
                        <span className="text-sm truncate flex-1">
                          {dimension?.name || dimensionId}
                        </span>
                        {/* <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 opacity-0 group-hover:opacity-100 flex-shrink-0"
                          onClick={() => handleRemoveDimension(dimensionId)}
                        >
                          <X className="h-3 w-3" />
                        </Button> */}
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
            {/* <div className="p-3 border-t flex-shrink-0">
              <Button
                variant="outline"
                className="w-full h-8 text-xs"
                onClick={() => setIsAddDimensionOpen(true)}
              >
                <Plus className="h-3.5 w-3.5 mr-1.5" />
                Add Dimension
              </Button>
            </div> */}
          </Card>

          {/* Breakdown Section */}
          <Card className="flex-shrink-0">
            <CardContent className="p-3 space-y-3">
              {/* Breakdown */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Breakdown
                </label>
                <Select
                  value={breakdownDimension}
                  onValueChange={setBreakdownDimension}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <div className="flex items-center gap-2">
                      <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
                      <SelectValue placeholder="Select dimension" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {availableDimensions.map((dim) => (
                      <SelectItem key={dim.id} value={dim.id}>
                        {dim.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Rows Per Dimension */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Rows Per Dimension
                </label>
                <Select
                  value={rowsPerDimension}
                  onValueChange={setRowsPerDimension}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5</SelectItem>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="15">15</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Show Elapsed Time */}
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Show Elapsed Time
                </label>
                <Switch
                  checked={showElapsedTime}
                  onCheckedChange={setShowElapsedTime}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Funnel Visualization & Table */}
        <div className="flex-1 overflow-y-auto pr-2">
          <div className="flex flex-col gap-3">
            {/* Funnel Chart Card */}
            <Card>
              <CardHeader className="border-b py-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Funnel Visualization
                  </CardTitle>
                  <Badge variant="outline">
                    {funnelData.steps.length} step
                    {funnelData.steps.length !== 1 ? "s" : ""}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-3">
                {usersFunnelLoading || eventNamesLoading ? (
                  <div className="flex items-center justify-center h-[200px]">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <FunnelVisualization data={funnelData} />
                )}
              </CardContent>
            </Card>

            {/* Funnel Data Table */}
            {funnelData.steps.length > 0 && (
              <Card>
                <CardHeader className="border-b py-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      Funnel Data Breakdown
                      {breakdownDimension && breakdownDimension !== "none" && (
                        <Badge variant="secondary" className="text-xs">
                          by{" "}
                          {availableDimensions.find(
                            (d) => d.id === breakdownDimension
                          )?.name || breakdownDimension}
                        </Badge>
                      )}
                    </CardTitle>
                    <span className="text-xs text-muted-foreground">
                      {breakdownDimension && breakdownDimension !== "none"
                        ? `Showing ${rowsPerDimension} rows per dimension`
                        : "Select breakdown dimension to see detailed data"}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <FunnelTable
                    data={funnelData}
                    breakdownDimension={breakdownDimension}
                    rowsPerDimension={parseInt(rowsPerDimension)}
                  />
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Event Search Modal */}
      <EventSearchModal
        open={isAddEventOpen}
        onOpenChange={setIsAddEventOpen}
        events={events}
        selectedSteps={selectedSteps}
        onAddEvent={(eventName) => {
          handleAddEvent(eventName);
          // Don't close the modal to allow adding multiple events
        }}
        onRemoveEvent={(eventName) => {
          handleRemoveEvent(eventName);
        }}
        loading={eventNamesLoading}
      />

      {/* Dimension Search Modal */}
      <DimensionSearchModal
        open={isAddDimensionOpen}
        onOpenChange={setIsAddDimensionOpen}
        availableDimensions={availableDimensions}
        selectedDimensions={selectedDimensions}
        onAddDimension={(dimensionId) => {
          handleAddDimension(dimensionId);
          // Don't close the modal to allow adding multiple dimensions
        }}
        onRemoveDimension={(dimensionId) => {
          handleRemoveDimension(dimensionId);
        }}
      />

      {/* Segment Selection Modal */}
      <Dialog open={isAddSegmentOpen} onOpenChange={setIsAddSegmentOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh]">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <DialogTitle className="text-xl">Add a new segment</DialogTitle>
                <span className="text-sm text-muted-foreground">
                  {selectedSegments.length} of {AVAILABLE_SEGMENTS.length}{" "}
                  selected
                </span>
              </div>
            </div>
          </DialogHeader>

          <div className="flex items-center gap-3 py-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search"
                value={segmentSearchQuery}
                onChange={(e) => setSegmentSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline">Create a new segment</Button>
            <Button
              onClick={() => setIsAddSegmentOpen(false)}
              className="bg-primary"
            >
              Confirm
            </Button>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <ScrollArea className="h-[400px]">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0 z-10">
                  <tr className="border-b">
                    <th className="w-12 py-3 px-4"></th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                      Segment name
                    </th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                      Description
                    </th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                      Conditions
                    </th>
                    <th className="w-12 py-3 px-4"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSegments.map((segment) => {
                    const isSelected = selectedSegments.includes(segment.id);
                    return (
                      <tr
                        key={segment.id}
                        className={cn(
                          "border-b hover:bg-muted/30 transition-colors cursor-pointer",
                          isSelected && "bg-primary/5"
                        )}
                        onClick={() => handleToggleSegment(segment.id)}
                      >
                        <td className="py-3 px-4">
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() =>
                              handleToggleSegment(segment.id)
                            }
                          />
                        </td>
                        <td className="py-3 px-4 font-medium">
                          {segment.name}
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">
                          {segment.description}
                        </td>
                        <td className="py-3 px-4 text-muted-foreground text-xs max-w-[250px] truncate">
                          {segment.conditions || "-"}
                        </td>
                        <td className="py-3 px-4">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                          >
                            <ChevronDown className="h-4 w-4 rotate-[-90deg]" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </ScrollArea>
          </div>

          <div className="flex items-center justify-between pt-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <span>Items per page:</span>
              <Select defaultValue="25">
                <SelectTrigger className="w-[70px] h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <span>
              1 – {filteredSegments.length} of {AVAILABLE_SEGMENTS.length}
            </span>
          </div>
        </DialogContent>
      </Dialog>

      {/* Save Funnel Dialog */}
      <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Funnel</DialogTitle>
            <DialogDescription>
              Save your current funnel configuration for later use
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Funnel Name</Label>
              <Input
                placeholder="Enter funnel name..."
                value={saveFunnelName}
                onChange={(e) => setSaveFunnelName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Steps ({selectedSteps.length})</Label>
              <div className="flex flex-wrap gap-1">
                {selectedSteps.map((step, index) => (
                  <Badge key={index} variant="secondary">
                    {index + 1}. {step.replace(/_/g, " ")}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsSaveDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveFunnel}
              disabled={!saveFunnelName.trim()}
            >
              <Save className="h-4 w-4 mr-2" />
              Save Funnel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FunnelAnalytics;
